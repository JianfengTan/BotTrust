import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.LinkedBlockingQueue;


/** 
 * This is CISC 3150 project 2: Problem A. Bot Trust 
 * 
 * @author:Jianfeng Tan
 * 
 */

public class Test extends JFrame implements ActionListener {

	/**
	 * This is a GUI that visualizes the solution
	 */
	private static final long serialVersionUID = 1L;
	private JButton sButton = new JButton("A-small-practice file");
	private JButton lButton = new JButton("A-large-practice file");
	private JButton qButton = new JButton("Quit");
	private JTextArea area;
    private JScrollPane scroll;
    private Thread t;
    private Scanner sc;
	

	public Test(){
		super("Project 2--Jianfeng Tan--BotTrust");
		Container cp= getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(1,2));
		area = new JTextArea();
		area.setEditable(false);
		scroll =new JScrollPane(area);
		scroll.setBounds(40,20,600,500);
		add(scroll);
			
		p.add(sButton);
		p.add(lButton);
		p.add(qButton);
		cp.add(p, BorderLayout.SOUTH);
		setSize(700,700);
		
		sButton.addActionListener(this);
		lButton.addActionListener(this);
		qButton.addActionListener(this);
			
	}
		
	/**
	 * This is BotTrust Class
	 */	
	 public static void main(String[] args)
	 {
		 Test BotTrust = new Test();
		 BotTrust.setVisible(true);
		 BotTrust.start();
	 }
	 
	 
	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		    // click button "A-small-practice" load the file ("A-small-practice.in")
			if(arg0.getSource()==sButton){
				area.setText("");
            try {
				sc = new Scanner(new File("A-small-practice.in"));
			} catch (FileNotFoundException e) {
				e.printStackTrace();}
			}
			
			// click button "A-large-practice" load the file ("A-large-practice.in")	         
	        else if (arg0.getSource()==lButton){
	        	area.setText("");
            try {
				sc = new Scanner(new File("A-large-practice.in"));
			} catch (FileNotFoundException e) {
				e.printStackTrace();}
			}
		
			// click button "quick", exit the window	            
	        else if (arg0.getSource()==qButton){
        	 
            	System.exit(0);
	        }        	            		        	
	        
			// This is main method handle the BotTrust problem
	        int cases = sc.nextInt();
	        for(int c=1; c<=cases; c++) {
	            int buttons = sc.nextInt();
	            boolean[] oTurn = new boolean[buttons];
	            Queue<Integer> oMoves = new LinkedBlockingQueue<Integer>();
	            Queue<Integer> bMoves = new LinkedBlockingQueue<Integer>();
	            for(int i=0; i<buttons; i++) {
	                char bot = sc.next().charAt(0);
	                int button = sc.nextInt();
	                
	                if (bot == 'O') {
	                    oMoves.add(button);
	                    oTurn[i] = true;
	                } else {
	                    bMoves.add(button);
	                    oTurn[i] = false;
	                }
	            }
		            
	            int time = 0;
	            int oLoc = 1;
	            int bLoc = 1;
	            int turn = 0;
	            boolean removed = false;
	            while (oMoves.size() > 0 || bMoves.size() > 0) {
	                removed = false;
	                if (oMoves.size() > 0) {
	                    int dest = oMoves.element();
	                    if (oLoc < dest) oLoc++;
	                    else if (oLoc > dest) oLoc--;
	                    else {
	                        if (oTurn[turn]) {
	                            removed = true;
	                            oMoves.remove();
	                            turn++;
	                        }
	                    }
	                }
	                if(bMoves.size() > 0) {
	                    int dest = bMoves.element();
	                    if (bLoc < dest) bLoc++;
	                    else if (bLoc > dest) bLoc--;
	                    else {
	                        if (!oTurn[turn] && !removed) {
	                            bMoves.remove();
	                            turn++;
	                        }
	                    }
	                }
	                time++;
	            }	
		      area.append("Case #" + c + ": " + time+ "\n\r");  
	        }
	        
		 }
		
	
	 /**
	 * This is use multiple threads to simulate multiple actors if there are multiple actors involved
	 */	
	   public void start ()
	   {
	    String threadName = null;
		System.out.println("Starting " +  threadName );
	      if (t == null)
	      {
	         t = new Thread ();
	         t.start ();
	      }
	   }	
	        	 	
}
